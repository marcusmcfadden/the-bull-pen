import sqlite3
import bcrypt

db_name = "bullpen.db"

def init_db():
    # Initializes the SQLite database and creates the cadets table.
    conn = sqlite3.connect(db_name)
    cursor = conn.cursor()
     
    # Tiers: 1=Full Admin, 2=Limited Admin, 3=Standard User.
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS cadets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            ms_level INTEGER,
            school TEXT,
            squad TEXT,
            tier INTEGER DEFAULT 3, 
            password_hash BLOB,
            status TEXT DEFAULT 'N'
        )
    ''')
    conn.commit()
    conn.close()
    print("Database initialized successfully.")

def register_cadet(name, ms_level, school, squad, tier, password):
    # Hashes the password and saves a new cadet to the database.
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    
    conn = sqlite3.connect(db_name)
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO cadets (name, ms_level, school, squad, tier, password_hash) VALUES (?, ?, ?, ?, ?, ?)",
            (name, ms_level, school, squad, tier, hashed)
        )
        conn.commit()
        return True
    except Exception as e:
        print(f"Error registering cadet: {e}")
        return False
    finally:
        conn.close()

def get_filtered_cadets(search_query, schools, squads, ms_levels, direction="ASC"):
    import sqlite3
    conn = sqlite3.connect("bullpen.db")
    cursor = conn.cursor()
    
    # 1. Base Query - Start with Name Search
    query = "SELECT name, ms_level, school, squad FROM cadets WHERE name LIKE ?"
    params = [f'%{search_query}%']
    
    # 2. Logic: Multi-Filter Checkboxes
    # If the list isn't empty, we add an "IN" clause to the SQL
    if schools:
        query += f" AND school IN ({','.join(['?'] * len(schools))})"
        params.extend(schools)
        
    if squads:
        query += f" AND squad IN ({','.join(['?'] * len(squads))})"
        params.extend(squads)
        
    if ms_levels:
        query += f" AND ms_level IN ({','.join(['?'] * len(ms_levels))})"
        params.extend(ms_levels)
        
    # 3. Sorting
    query += f" ORDER BY name {direction}"
    
    cursor.execute(query, params)
    rows = cursor.fetchall()
    conn.close()
    return rows

if __name__ == "__main__":
    init_db()