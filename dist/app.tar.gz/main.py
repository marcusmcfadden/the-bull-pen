import flet as ft
from database import init_db, get_filtered_cadets

def main(page: ft.Page):
    init_db()
    
    # Page Configuration
    page.title = "THE BULL PEN"
    page.theme_mode = ft.ThemeMode.DARK
    page.padding = 0

    # State Management
    active_schools = set()
    active_squads = set()
    active_ms = set()
    sort_ascending = True

    # Logic Functions
    def update_roster(e=None):
        query = search_field.value if search_field.value else ""
        direction = "ASC" if sort_ascending else "DESC"
        cadets = get_filtered_cadets(query, list(active_schools), list(active_squads), list(active_ms), direction)
        
        roster_list.controls.clear()
        for name, ms, school, squad in cadets:
            school_color = "#012169" if school == "D" else "#8B2331"
            roster_list.controls.append(
                ft.Card(
                    content=ft.ListTile(
                        leading=ft.CircleAvatar(content=ft.Text(name[0]), bgcolor=school_color),
                        title=ft.Text(name),
                        subtitle=ft.Text(f"MS{ms} | {squad}"),
                        trailing=ft.Text(school, weight="bold", color=school_color, size=15)
                    )
                )
            )
        page.update()

    def toggle_sort(e):
        nonlocal sort_ascending
        sort_ascending = not sort_ascending
        sort_dir_btn.icon = ft.Icons.ARROW_UPWARD if sort_ascending else ft.Icons.ARROW_DOWNWARD
        sort_dir_btn.tooltip = "Sort Ascending" if sort_ascending else "Sort Descending"
        update_roster()

    def on_filter_change(e):
        val, category = e.control.label, e.control.data
        if category == "school":
            val_to_add = "D" if "Duke" in val else "N"
        elif category == "squad":
            val_to_add = f"{val} Squad" if val != "MS4" else val
        else:
            val_to_add = val

        target_set = {"school": active_schools, "squad": active_squads, "ms": active_ms}[category]
        if e.control.value:
            target_set.add(val_to_add)
        else:
            target_set.discard(val_to_add)
        update_roster()

    def toggle_filter_box(e):
        if page.width > 800:
            filter_sidebar.visible = not filter_sidebar.visible
        else:
            filter_anchor.visible = not filter_anchor.visible
        page.update()

    def show_view(is_roster):
        filter_anchor.visible = False
        roster_view.visible, task_org_view.visible = is_roster, not is_roster
        btn_roster.bgcolor = "#012169" if is_roster else ft.Colors.GREY_900
        btn_task_org.bgcolor = "#8B2331" if not is_roster else ft.Colors.GREY_900
        page.update()

    # UI Builders
    def build_filters():
        return ft.Column([
            ft.Text("FILTERS", size=14, weight="bold", color="blue400"),
            ft.Divider(height=1, color="white10"),
            ft.Text("SCHOOL:", size=11, weight="bold", color="grey500"),
            ft.Checkbox(label="Duke", data="school", on_change=on_filter_change, scale=0.9),
            ft.Checkbox(label="NCCU", data="school", on_change=on_filter_change, scale=0.9),
            ft.Divider(height=1, color="white10"),
            ft.Text("SQUAD:", size=11, weight="bold", color="grey500"),
            ft.Checkbox(label="1st", data="squad", on_change=on_filter_change, scale=0.9),
            ft.Checkbox(label="2nd", data="squad", on_change=on_filter_change, scale=0.9),
            ft.Checkbox(label="3rd", data="squad", on_change=on_filter_change, scale=0.9),
            ft.Checkbox(label="4th", data="squad", on_change=on_filter_change, scale=0.9),
            ft.Divider(height=1, color="white10"),
            ft.Text("MS LEVEL:", size=11, weight="bold", color="grey500"),
            ft.Row([
                ft.Checkbox(label="1", data="ms", on_change=on_filter_change, scale=0.8),
                ft.Checkbox(label="2", data="ms", on_change=on_filter_change, scale=0.8),
                ft.Checkbox(label="3", data="ms", on_change=on_filter_change, scale=0.8),
                ft.Checkbox(label="4", data="ms", on_change=on_filter_change, scale=0.8),
            ], wrap=True, spacing=0)
        ], tight=True, spacing=5, scroll=ft.ScrollMode.AUTO)

    # Search and Filter Components
    search_field = ft.TextField(
        hint_text="Search Name...", 
        prefix_icon=ft.Icons.SEARCH, 
        expand=True, 
        on_change=update_roster,
        border_radius=10,
        height=45,
        text_size=14
    )
    
    sort_dir_btn = ft.IconButton(ft.Icons.ARROW_UPWARD, on_click=toggle_sort, icon_size=20)
    
    filter_toggle_btn = ft.IconButton(
        icon=ft.Icons.FILTER_ALT_OUTLINED,
        on_click=toggle_filter_box,
        icon_size=20
    )

    roster_list = ft.ListView(expand=True, spacing=5)

    # --- UPDATED NAV DRAWER (HELLO WORLD ONLY) ---
    page.drawer = ft.NavigationDrawer(
        controls=[
            ft.Container(
                content=ft.Text("Hello World", size=24, weight="bold", color="white"),
                padding=40
            )
        ],
    )

    # Sidebar for Desktop
    filter_sidebar = ft.Container(
        content=build_filters(),
        width=250,
        bgcolor=ft.Colors.BLACK,
        padding=20,
        border=ft.border.only(left=ft.border.BorderSide(1, "white10")),
        visible=page.width > 800
    )

    # Floating Filter Anchor for Mobile
    filter_anchor = ft.TransparentPointer(
        content=ft.Container(
            content=ft.Container(
                content=build_filters(),
                padding=15,
                bgcolor=ft.Colors.GREY_900,
                border=ft.border.all(1, "white10"),
                border_radius=12,
                width=240,
                height=400,
                shadow=ft.BoxShadow(blur_radius=20, color="black")
            ),
            alignment=ft.Alignment(1, -1),
            padding=ft.padding.only(top=140, right=15), 
        ),
        visible=False
    )

    # Main Layouts
    roster_main_col = ft.Container(
        content=ft.Column([
            ft.Row([search_field, sort_dir_btn, filter_toggle_btn], spacing=5),
            roster_list 
        ], spacing=15),
        expand=True,
        padding=15
    )

    roster_view = ft.Stack([
        ft.Row([roster_main_col, filter_sidebar], expand=True, spacing=0),
        filter_anchor
    ], expand=True)

    task_org_view = ft.Container(
        content=ft.Text("Task Organization View (Placeholder)", color="white"),
        bgcolor="black", padding=20, expand=True, visible=False,
    )
    
    page.appbar = ft.AppBar(
        title=ft.Text("THE BULL PEN", weight="bold"), 
        bgcolor=ft.Colors.BLACK,
        center_title=True
    )

    # Bottom Nav
    rect_style = ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=0))
    btn_roster = ft.ElevatedButton(
        "ROSTER", bgcolor="#012169", color="white", 
        on_click=lambda _: show_view(True), 
        expand=True, height=60, style=rect_style
    )
    btn_task_org = ft.ElevatedButton(
        "TASK ORG", bgcolor="grey900", color="white", 
        on_click=lambda _: show_view(False), 
        expand=True, height=60, style=rect_style
    )

    def on_page_resize(e):
        if page.width > 800:
            filter_sidebar.visible = True
            filter_anchor.visible = False
            page.appbar.leading = None
        else:
            filter_sidebar.visible = False
            page.appbar.leading = hamburger_btn
        page.update()

    page.on_resize = on_page_resize
    
    page.add(
        ft.Column([
            ft.Container(content=ft.Stack([roster_view, task_org_view], expand=True), expand=True), 
            ft.Row([btn_roster, btn_task_org], spacing=0)
        ], expand=True, spacing=0)
    )
    
    update_roster()

if __name__ == "__main__":
    ft.app(target=main, view=ft.AppView.WEB_BROWSER, port=8550)